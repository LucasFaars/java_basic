public class Main{
	public static void main(String[] args) {
		 Carro carro1 = new Carro("Sla","tbm", 31);
		 Moto Moto1 = new Moto("muitas","vish","muito",21);
	}
}