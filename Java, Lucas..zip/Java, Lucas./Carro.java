public class Carro extends Veiculo{
    private int numeroPortas = 4;
    
    public Carro(String marca, String modelo, int ano){
        super(marca, modelo, ano);
    }
    
    public void abrirPortas(){
    
        System.out.println("Abrindo");
    }
    
    @Override
    public void ligar(){
        super.ligar();
    }
    
    @Override
    public void getDescricao(){
        super.getDescricao();
    }
    
    
    
}