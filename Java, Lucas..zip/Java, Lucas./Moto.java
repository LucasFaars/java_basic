public class Moto extends Veiculo{
    private String cilindradas;

    
    public Moto(String cilindradas, String marca, String modelo, int ano){
        super(marca, modelo, ano);
        this.cilindradas = cilindradas;
        
    }
    
    public void Empinar(){
        System.out.println("A moto está empinando...");
    }
    
    @Override
    public void ligar(){
        super.ligar();
    }
    
}