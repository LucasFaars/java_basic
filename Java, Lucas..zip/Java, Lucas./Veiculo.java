public class Veiculo{
    private String marca;
    private String modelo;
    private int ano;
    
    public Veiculo(String marca, String modelo, int ano){
        this.marca = marca;
        this.modelo = modelo;
        this.ano = ano;

    }
    
    public String getMarca(){
        return marca;
    }
    
    public void setMarca(String marca){
        this.marca = marca;
    }
    
    public void getDescricao(){
        System.out.println("Marca: " + marca + ", Modelo: " + modelo + ", Ano: " + ano + ".");
    }
    
    public void ligar(){
        System.out.println("Ligando... " + marca);
    }
    
    
    
}